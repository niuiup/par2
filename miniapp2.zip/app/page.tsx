export default function Home() {
  return <div>MiniApp main page</div>;
}