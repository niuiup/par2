export default function MiniAppPage(){
  return <div>MiniApp works!</div>
}